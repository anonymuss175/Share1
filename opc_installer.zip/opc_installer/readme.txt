Using the Oracle Database Cloud Backup Module Installer

Package content - This zip archive contains two versions of the Database Backup Cloud Module installer

1)  Oracle Cloud Infrastructure (gen2 cloud) - The readme file containing the installation instructions are in the oci_installer\oci_readme.txt file.  Use this module and instructions only if you are backing up to the Oracle Cloud Infrastructure buckets.  The endpoint has the form https://objectstorage.<region>.oraclecloud.com

2) Oracle Cloud Infrastructure Classic � The readme file containing the installation instructions are in the opc_installer\opc_readme.txt file.  Use this module and instructions only if you are backing up to the Oracle Cloud Infrastructure Classic containers.  The endpoint has the form https://storage.<region>.oraclecloud.com

For example:

https://objectstorage.us-phoenix-1.oraclecloud.com is an Oracle Cloud Infrastructure endpoint, so the oci_installer must be used.

https://storage.us2.oraclecloud.com is an OCI Oracle Cloud Infrastructure Classic endpoint, so the opc_installer must be used

NOTE: Oracle Cloud Infrastructure (gen2) also offers endpoints compatible with the opc_installer, they start with swiftobjecstorage, instead of just objecstorage. Those endpoints were meant to provide backward compatibility with the opc_installer module. For new installations those endpoints must not be used anymore. For existing installation it's recommended to move to the new oci_installer module as soon as possible, but the existing backups must be re-cataloged using the rman catalog backuppiece... command.
