Summary
-------
This is README file for AgentPatching tool, which is used for patching Oracle Management Agent Release 13.5.0.0.0

This patch installs the "AgentPatcher" utility. AgentPatcher is used for patching Oracle Management Agent.
 
If you have an older version of AgentPatcher it is strongly recommended to back it up before upgrading to the new AgentPatcher.



How to install the utility:
---------------------------

To install this patch, Please extract the file "zipped file" using unzip or winzip,
depending upon the platform. You should extract the zip file directly under the
ORACLE_HOME. Please follow the following steps for extracting the zip file of AgentPatcher.

(1)  Please take a backup of ORACLE_HOME/AgentPatcher into a dedicated backup
location.
(2) Please make sure no directory ORACLE_HOME/AgentPatcher exist.
(3) Please unzip the AgentPatcher downloaded zip into ORACLE_HOME directory.



============================================================================
